package com.example.storywatpad.support;

public class Utils {
    public static final String EMAIL = "transontungpl03@gmail.com";
    public static final String PASSWORD = "cjha kasx xilr nvzq";

}
